import { defineMiddleware } from 'astro:middleware';
import { getSessionUser } from '@/lib/server/auth';
import { getBranding } from '@/lib/server/branding';
import { db } from '@/lib/db/client';

export const onRequest = defineMiddleware(async (context, next) => {
  const { url, request, locals } = context;

  // Initialize branding on every request
  try {
    const branding = await getBranding();
    locals.branding = branding;
  } catch (error) {
    console.error('Failed to load branding:', error);
  }

  // Get session token from cookie
  const sessionCookie = request.headers.get('cookie')
    ?.split(';')
    .find(c => c.trim().startsWith('sched_session='))
    ?.split('=')[1];

  if (sessionCookie) {
    try {
      const user = await getSessionUser(sessionCookie);
      if (user) {
        locals.user = user;
      }
    } catch (error) {
      console.error('Failed to get session user:', error);
    }
  }

  // Check if setup is needed (no users exist)
  let setupNeeded = false;
  try {
    const userCount = await db`SELECT COUNT(*) as count FROM users`;
    setupNeeded = (userCount[0]?.count ?? 0) === 0;
  } catch (error) {
    // Schema might not exist yet, that's ok
  }

  const path = url.pathname;

  // Redirect logic
  if (path === '/') {
    if (setupNeeded) {
      return context.redirect('/setup');
    }
    if (!locals.user) {
      return context.redirect('/login');
    }
    return context.redirect('/schedule');
  }

  // Setup page - redirect away if setup already done
  if (path === '/setup' && !setupNeeded) {
    if (locals.user) {
      return context.redirect('/schedule');
    }
    return context.redirect('/login');
  }

  // Login/setup pages don't need auth
  if (path === '/login' || path === '/setup') {
    return next();
  }

  // API routes
  if (path.startsWith('/api/auth/login') || path.startsWith('/api/auth/logout')) {
    return next();
  }

  // API /api/branding GET is public
  if (path === '/api/branding' && request.method === 'GET') {
    return next();
  }

  // All other routes require auth
  if (!locals.user) {
    if (path.startsWith('/api/')) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { 'Content-Type': 'application/json' },
      });
    }
    return context.redirect('/login');
  }

  // Admin routes require admin role (owner or manager)
  if (path.startsWith('/admin/')) {
    if (locals.user.role !== 'owner' && locals.user.role !== 'manager') {
      if (path.startsWith('/api/')) {
        return new Response(JSON.stringify({ error: 'Forbidden' }), {
          status: 403,
          headers: { 'Content-Type': 'application/json' },
        });
      }
      return context.redirect('/schedule');
    }

    // /admin/branding requires owner role
    if (path === '/admin/branding' && locals.user.role !== 'owner') {
      return context.redirect('/admin');
    }
  }

  return next();
});

declare global {
  namespace App {
    interface Locals {
      user?: {
        id: number;
        username: string;
        full_name: string;
        role: 'owner' | 'manager' | 'staff';
      };
      branding?: {
        id: number;
        business_name: string;
        tagline: string;
        logo_url?: string;
        primary_color: string;
        accent_color: string;
        contact_email?: string;
      };
    }
  }
}
