/// <reference types="astro/client" />

declare namespace App {
  interface Locals {
    user?: {
      id: number;
      username: string;
      full_name: string;
      role: 'owner' | 'manager' | 'staff';
    };
  }
}
