import { db, dbSingle } from '@/lib/db/client';
import type { AppBranding } from '@/lib/types';

export async function getBranding(): Promise<AppBranding> {
  const branding = await dbSingle<AppBranding>`
    SELECT * FROM app_branding WHERE id = 1
  `;

  if (branding) return branding;

  // Default branding if no row exists
  return {
    id: 1,
    business_name: 'My Business',
    tagline: 'Staff Schedule',
    primary_color: '#dc2626',
    accent_color: '#fbbf24',
  } as AppBranding;
}

export async function updateBranding(updates: Partial<AppBranding>): Promise<AppBranding> {
  const {
    business_name,
    tagline,
    logo_url,
    primary_color,
    accent_color,
    contact_email,
  } = updates;

  // Update or insert
  const result = await dbSingle<AppBranding>`
    INSERT INTO app_branding (
      id, business_name, tagline, logo_url, primary_color, accent_color, contact_email, updated_at
    ) VALUES (
      1,
      ${business_name || 'My Business'},
      ${tagline || 'Staff Schedule'},
      ${logo_url || null},
      ${primary_color || '#dc2626'},
      ${accent_color || '#fbbf24'},
      ${contact_email || null},
      NOW()
    )
    ON CONFLICT (id) DO UPDATE SET
      business_name = EXCLUDED.business_name,
      tagline = EXCLUDED.tagline,
      logo_url = EXCLUDED.logo_url,
      primary_color = EXCLUDED.primary_color,
      accent_color = EXCLUDED.accent_color,
      contact_email = EXCLUDED.contact_email,
      updated_at = NOW()
    RETURNING *
  `;

  if (!result) throw new Error('Failed to update branding');
  return result;
}
