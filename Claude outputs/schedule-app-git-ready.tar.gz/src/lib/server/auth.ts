import { hash, verify } from '@node-rs/argon2';
import { randomBytes } from 'crypto';
import { db, dbSingle } from '@/lib/db/client';
import type { Session, AuthUser } from '@/lib/types';

const SESSION_DURATION_DAYS = 30;

export async function hashPassword(password: string): Promise<string> {
  return hash(password, {
    memoryCost: 19456,
    timeCost: 2,
    parallelism: 1,
  });
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  try {
    return await verify(hash, password);
  } catch {
    return false;
  }
}

export function generateSessionToken(): string {
  return randomBytes(32).toString('hex');
}

export async function createSession(userId: number): Promise<string> {
  const token = generateSessionToken();
  const expiresAt = new Date();
  expiresAt.setDate(expiresAt.getDate() + SESSION_DURATION_DAYS);

  await db`
    INSERT INTO sessions (token, user_id, expires_at)
    VALUES (${token}, ${userId}, ${expiresAt.toISOString()})
  `;

  return token;
}

export async function getSessionUser(token: string): Promise<AuthUser | null> {
  const session = await dbSingle<Session & { user_id: number }>`
    SELECT s.token, s.user_id, s.expires_at, u.id, u.username, u.full_name, u.role
    FROM sessions s
    JOIN users u ON s.user_id = u.id
    WHERE s.token = ${token}
    AND s.expires_at > NOW()
    AND u.active = true
  `;

  if (!session) return null;

  return {
    id: session.user_id,
    username: session.username,
    full_name: session.full_name,
    role: session.role as 'owner' | 'manager' | 'staff',
  };
}

export async function deleteSession(token: string): Promise<void> {
  await db`DELETE FROM sessions WHERE token = ${token}`;
}

export function isAdmin(role: string): boolean {
  return role === 'owner' || role === 'manager';
}

export function isOwner(role: string): boolean {
  return role === 'owner';
}
