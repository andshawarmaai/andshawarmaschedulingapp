export type UserRole = 'owner' | 'manager' | 'staff';

export interface User {
  id: number;
  username: string;
  full_name: string;
  password_hash: string;
  role: UserRole;
  phone?: string;
  hourly_rate_cents?: number;
  active: boolean;
  created_at: string;
}

export interface Shift {
  id: number;
  user_id: number;
  starts_at: string;
  ends_at: string;
  role?: string;
  notes?: string;
  created_at: string;
}

export interface TimeOffRequest {
  id: number;
  user_id: number;
  starts_at: string;
  ends_at: string;
  reason?: string;
  status: 'pending' | 'approved' | 'denied';
  reviewed_by?: number;
  reviewed_at?: string;
  created_at: string;
}

export interface ShiftSwap {
  id: number;
  shift_id: number;
  from_user_id: number;
  to_user_id?: number;
  status: 'open' | 'claimed' | 'approved' | 'cancelled';
  created_at: string;
}

export interface Session {
  token: string;
  user_id: number;
  expires_at: string;
  created_at: string;
}

export interface AppBranding {
  id: number;
  business_name: string;
  tagline: string;
  logo_url?: string;
  primary_color: string;
  accent_color: string;
  contact_email?: string;
  updated_at: string;
}

export interface AuthUser {
  id: number;
  username: string;
  full_name: string;
  role: UserRole;
}
