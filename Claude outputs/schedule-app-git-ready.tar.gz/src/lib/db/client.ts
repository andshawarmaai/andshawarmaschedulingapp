import { sql } from '@neondatabase/serverless';
import schemaSql from './schema.sql?raw';

let schemaInitialized = false;

async function ensureSchema() {
  if (schemaInitialized) return;

  try {
    // Run entire schema as one batch
    const queries = schemaSql
      .split(';')
      .map(q => q.trim())
      .filter(q => q.length > 0);

    for (const query of queries) {
      await sql(query);
    }

    schemaInitialized = true;
  } catch (error) {
    console.error('Failed to initialize schema:', error);
    throw error;
  }
}

export async function db<T>(
  strings: TemplateStringsArray,
  ...values: any[]
): Promise<T[]> {
  await ensureSchema();
  return sql(strings, ...values);
}

export async function dbSingle<T>(
  strings: TemplateStringsArray,
  ...values: any[]
): Promise<T | null> {
  const results = await db<T>(strings, ...values);
  return results[0] ?? null;
}

export { ensureSchema };
