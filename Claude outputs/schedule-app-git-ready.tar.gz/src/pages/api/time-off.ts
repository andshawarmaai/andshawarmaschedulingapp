import type { APIRoute } from 'astro';
import { db } from '@/lib/db/client';

export const POST: APIRoute = async (context) => {
  try {
    const user = context.locals.user;
    if (!user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    const data = await context.request.formData();
    const startsAt = data.get('starts_at')?.toString();
    const endsAt = data.get('ends_at')?.toString();
    const reason = data.get('reason')?.toString();

    if (!startsAt || !endsAt) {
      return new Response(JSON.stringify({ error: 'Missing required fields' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    await db`
      INSERT INTO time_off_requests (user_id, starts_at, ends_at, reason)
      VALUES (${user.id}, ${startsAt}, ${endsAt}, ${reason || null})
    `;

    return new Response(JSON.stringify({ ok: true }), {
      status: 201,
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Create time-off request error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
};
