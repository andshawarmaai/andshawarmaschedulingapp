import type { APIRoute } from 'astro';
import { getBranding, updateBranding } from '@/lib/server/branding';
import { isOwner } from '@/lib/server/auth';

export const GET: APIRoute = async () => {
  try {
    const branding = await getBranding();
    return new Response(JSON.stringify(branding), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Get branding error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
};

export const PATCH: APIRoute = async (context) => {
  try {
    const user = context.locals.user;
    if (!user || !isOwner(user.role)) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 403,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    const data = await context.request.formData();
    const businessName = data.get('business_name')?.toString();
    const tagline = data.get('tagline')?.toString();
    const logoUrl = data.get('logo_url')?.toString();
    const primaryColor = data.get('primary_color')?.toString();
    const accentColor = data.get('accent_color')?.toString();
    const contactEmail = data.get('contact_email')?.toString();

    const updated = await updateBranding({
      business_name: businessName,
      tagline,
      logo_url: logoUrl,
      primary_color: primaryColor,
      accent_color: accentColor,
      contact_email: contactEmail,
    } as any);

    return new Response(JSON.stringify(updated), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Update branding error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
};
