import type { APIRoute } from 'astro';
import { db } from '@/lib/db/client';
import { isAdmin } from '@/lib/server/auth';

export const POST: APIRoute = async (context) => {
  try {
    const user = context.locals.user;
    if (!user || !isAdmin(user.role)) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 403,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    const { id } = context.params;

    // Update swap status and the shifts' user_ids
    const swap = await db`SELECT shift_id, from_user_id, to_user_id FROM shift_swaps WHERE id = ${parseInt(id || '0')}`;

    if (!swap || !swap[0]) {
      return new Response(JSON.stringify({ error: 'Swap not found' }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    const { shift_id, to_user_id } = swap[0] as any;

    // Update the shift to the new user
    await db`UPDATE shifts SET user_id = ${to_user_id} WHERE id = ${shift_id}`;

    // Mark swap as approved
    await db`UPDATE shift_swaps SET status = 'approved' WHERE id = ${parseInt(id || '0')}`;

    return new Response(JSON.stringify({ ok: true }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Approve swap error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
};
