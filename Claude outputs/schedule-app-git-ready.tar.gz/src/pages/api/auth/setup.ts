import type { APIRoute } from 'astro';
import { db } from '@/lib/db/client';
import { hashPassword, createSession } from '@/lib/server/auth';
import { updateBranding } from '@/lib/server/branding';

export const POST: APIRoute = async (context) => {
  try {
    const data = await context.request.formData();

    // Get branding data
    const businessName = data.get('business_name')?.toString() || 'My Business';
    const tagline = data.get('tagline')?.toString() || 'Staff Schedule';
    const logoUrl = data.get('logo_url')?.toString() || null;
    const primaryColor = data.get('primary_color')?.toString() || '#dc2626';
    const accentColor = data.get('accent_color')?.toString() || '#fbbf24';
    const contactEmail = data.get('contact_email')?.toString() || null;

    // Get owner account data
    const fullName = data.get('full_name')?.toString();
    const username = data.get('username')?.toString();
    const password = data.get('password')?.toString();
    const confirmPassword = data.get('confirm_password')?.toString();

    // Validate
    if (!fullName || !username || !password || !confirmPassword) {
      return new Response(JSON.stringify({ error: 'Missing required fields' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    if (password !== confirmPassword) {
      return new Response(JSON.stringify({ error: 'Passwords do not match' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    if (password.length < 6) {
      return new Response(JSON.stringify({ error: 'Password must be at least 6 characters' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    // Check if user already exists
    const existingUser = await db`
      SELECT id FROM users WHERE username = ${username}
    `;

    if (existingUser.length > 0) {
      return new Response(JSON.stringify({ error: 'Username already taken' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    // Create branding
    await updateBranding({
      business_name: businessName,
      tagline,
      logo_url: logoUrl,
      primary_color: primaryColor,
      accent_color: accentColor,
      contact_email: contactEmail,
    } as any);

    // Hash password
    const passwordHash = await hashPassword(password);

    // Create owner user
    const result = await db`
      INSERT INTO users (username, full_name, password_hash, role)
      VALUES (${username}, ${fullName}, ${passwordHash}, 'owner')
      RETURNING id
    `;

    if (!result || !result[0]) {
      throw new Error('Failed to create user');
    }

    const userId = (result[0] as any).id;

    // Create session
    const token = await createSession(userId);

    // Set session cookie and redirect
    const response = new Response(null, {
      status: 303,
      headers: {
        'Location': '/schedule',
        'Set-Cookie': `sched_session=${token}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${30 * 24 * 60 * 60}`,
      },
    });

    return response;
  } catch (error) {
    console.error('Setup error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
};
