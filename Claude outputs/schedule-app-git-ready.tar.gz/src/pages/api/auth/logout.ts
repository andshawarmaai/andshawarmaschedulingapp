import type { APIRoute } from 'astro';
import { deleteSession } from '@/lib/server/auth';

export const POST: APIRoute = async (context) => {
  const { request, redirect } = context;

  try {
    const sessionCookie = request.headers.get('cookie')
      ?.split(';')
      .find(c => c.trim().startsWith('sched_session='))
      ?.split('=')[1];

    if (sessionCookie) {
      await deleteSession(sessionCookie);
    }

    const response = new Response(null, {
      status: 303,
      headers: {
        'Location': '/login',
        'Set-Cookie': 'sched_session=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0',
      },
    });

    return response;
  } catch (error) {
    console.error('Logout error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
};
