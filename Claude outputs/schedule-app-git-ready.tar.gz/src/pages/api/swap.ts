import type { APIRoute } from 'astro';
import { db } from '@/lib/db/client';

export const POST: APIRoute = async (context) => {
  try {
    const user = context.locals.user;
    if (!user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    const data = await context.request.formData();
    const shiftId = data.get('shift_id')?.toString();

    if (!shiftId) {
      return new Response(JSON.stringify({ error: 'Missing shift_id' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    await db`
      INSERT INTO shift_swaps (shift_id, from_user_id)
      VALUES (${parseInt(shiftId)}, ${user.id})
    `;

    return new Response(JSON.stringify({ ok: true }), {
      status: 201,
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Create swap error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
};
