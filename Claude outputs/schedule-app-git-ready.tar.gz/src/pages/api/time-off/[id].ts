import type { APIRoute } from 'astro';
import { db } from '@/lib/db/client';
import { isAdmin } from '@/lib/server/auth';

export const PATCH: APIRoute = async (context) => {
  try {
    const user = context.locals.user;
    if (!user || !isAdmin(user.role)) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 403,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    const { id } = context.params;
    const data = await context.request.formData();
    const status = data.get('status')?.toString();

    if (!status || !['approved', 'denied'].includes(status)) {
      return new Response(JSON.stringify({ error: 'Invalid status' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    await db`
      UPDATE time_off_requests
      SET status = ${status}, reviewed_by = ${user.id}, reviewed_at = NOW()
      WHERE id = ${parseInt(id || '0')}
    `;

    return new Response(JSON.stringify({ ok: true }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Update time-off request error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
};
