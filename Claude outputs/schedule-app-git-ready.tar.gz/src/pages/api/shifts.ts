import type { APIRoute } from 'astro';
import { db } from '@/lib/db/client';
import { isAdmin } from '@/lib/server/auth';

export const POST: APIRoute = async (context) => {
  try {
    const user = context.locals.user;
    if (!user || !isAdmin(user.role)) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 403,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    const data = await context.request.formData();
    const userId = data.get('user_id')?.toString();
    const startsAt = data.get('starts_at')?.toString();
    const endsAt = data.get('ends_at')?.toString();
    const role = data.get('role')?.toString();
    const notes = data.get('notes')?.toString();

    if (!userId || !startsAt || !endsAt) {
      return new Response(JSON.stringify({ error: 'Missing required fields' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    await db`
      INSERT INTO shifts (user_id, starts_at, ends_at, role, notes)
      VALUES (${parseInt(userId)}, ${new Date(startsAt).toISOString()}, ${new Date(endsAt).toISOString()}, ${role || null}, ${notes || null})
    `;

    return new Response(JSON.stringify({ ok: true }), {
      status: 201,
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Create shift error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
};
