import type { APIRoute } from 'astro';
import { db } from '@/lib/db/client';
import { hashPassword } from '@/lib/server/auth';
import { isAdmin } from '@/lib/server/auth';

export const POST: APIRoute = async (context) => {
  try {
    const user = context.locals.user;
    if (!user || !isAdmin(user.role)) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 403,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    const data = await context.request.formData();
    const fullName = data.get('full_name')?.toString();
    const username = data.get('username')?.toString();
    const role = data.get('role')?.toString() || 'staff';
    const phone = data.get('phone')?.toString();
    const hourlyRateCents = data.get('hourly_rate_cents')?.toString();

    if (!fullName || !username) {
      return new Response(JSON.stringify({ error: 'Missing required fields' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    // Generate a temporary password
    const tempPassword = Math.random().toString(36).slice(-8);
    const passwordHash = await hashPassword(tempPassword);

    try {
      const result = await db`
        INSERT INTO users (username, full_name, password_hash, role, phone, hourly_rate_cents)
        VALUES (
          ${username},
          ${fullName},
          ${passwordHash},
          ${role},
          ${phone || null},
          ${hourlyRateCents ? parseInt(hourlyRateCents) : null}
        )
        RETURNING id
      `;

      return new Response(
        JSON.stringify({
          ok: true,
          message: `User created. Temporary password: ${tempPassword}`,
          userId: (result[0] as any).id,
        }),
        {
          status: 201,
          headers: { 'Content-Type': 'application/json' },
        }
      );
    } catch (error: any) {
      if (error.message?.includes('duplicate')) {
        return new Response(JSON.stringify({ error: 'Username already exists' }), {
          status: 400,
          headers: { 'Content-Type': 'application/json' },
        });
      }
      throw error;
    }
  } catch (error) {
    console.error('Create user error:', error);
    return new Response(JSON.stringify({ error: 'Internal server error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
};
