# Schedule App

A modern shift scheduling web app for restaurants and shift-based businesses. Staff see their weekly schedule, request time off, and swap shifts. Owners and managers build schedules, approve requests, and customize branding.

## Features

- Weekly shift scheduling view
- Time-off request management
- Shift swap marketplace
- Role-based access control (owner, manager, staff)
- Customizable branding per deployment
- Single-tenant per deployment (one database per customer)
- Serverless deployment on Vercel with Neon Postgres

## Quick Start

### Deploy to Vercel

Click the button below to deploy your own instance:

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/andshawarmaai/scheduling-app&env=POSTGRES_URL&envDescription=Your%20Neon%20Postgres%20connection%20string&envLink=https://console.neon.tech)

### Setup Steps

1. Click the Deploy button above
2. Log in to Vercel (free tier works)
3. When prompted for `POSTGRES_URL`:
   - Go to https://console.neon.tech
   - Sign up for a free Neon account (no credit card required)
   - Create a new project
   - Copy the connection string (looks like `postgresql://user:pass@ep-xxx.us-east-2.aws.neon.tech/neondb?sslmode=require`)
   - Paste it into Vercel
4. Vercel will build and deploy automatically
5. When deployment is complete, open your app URL
6. Fill out the setup wizard with your business name, colors, and admin credentials
7. Done! Your schedule app is live

### Local Development

```bash
# Install dependencies
pnpm install

# Start dev server
pnpm dev

# Build for production
pnpm build
```

For local development, you'll need a Postgres database. Set `POSTGRES_URL` environment variable or use:

```bash
docker run -d --name schedule-pg -p 5432:5432 -e POSTGRES_PASSWORD=dev postgres:16
# Connection string: postgresql://postgres:dev@localhost:5432/postgres
```

## Technology Stack

- **Framework:** Astro 5.x with SSR
- **Language:** TypeScript (strict mode)
- **Styling:** Tailwind CSS v4
- **Database:** Neon Postgres (serverless)
- **Auth:** HTTP-only session cookies with Argon2 password hashing
- **Deployment:** Vercel serverless functions

## User Roles

- **Owner:** Full admin access, can manage users, build schedules, approve requests, customize branding
- **Manager:** Can manage users, build schedules, approve requests
- **Staff:** Can view schedule, request time off, swap shifts

## Branding Customization

Every deployment is fully customizable:
- Business name and tagline
- Logo (upload to `public/` folder)
- Primary and accent colors (used throughout the UI)
- Contact email (displayed in footer)

Customers can edit branding anytime at `/admin/branding` (owner only).

## Database Schema

The app automatically creates all required tables on first request:
- `app_branding` - Business branding and customization
- `users` - Staff members with roles
- `shifts` - Scheduled work shifts
- `time_off_requests` - Approved/pending time-off
- `shift_swaps` - Shift swap offers and claims
- `sessions` - User session management

## API Routes

### Authentication
- `POST /api/auth/login` - Login
- `POST /api/auth/logout` - Logout
- `POST /api/auth/setup` - Initial setup (admin account creation)

### Users
- `POST /api/users` - Create user (admin only)
- `PATCH /api/users/[id]` - Update user
- `DELETE /api/users/[id]` - Deactivate user (owner only)

### Shifts
- `POST /api/shifts` - Create shift (admin only)
- `PATCH /api/shifts/[id]` - Update shift
- `DELETE /api/shifts/[id]` - Delete shift

### Time Off
- `POST /api/time-off` - Submit request
- `PATCH /api/time-off/[id]` - Approve/deny request (admin only)

### Swaps
- `POST /api/swap` - Create swap offer
- `POST /api/swap/[id]/claim` - Claim an open swap
- `POST /api/swap/[id]/approve` - Approve claimed swap (admin only)

### Branding
- `GET /api/branding` - Get current branding (public)
- `PATCH /api/branding` - Update branding (owner only)

## Environment Variables

```env
POSTGRES_URL=postgresql://user:pass@host/dbname?sslmode=require
```

That's it. One variable for everything.

## License

MIT
